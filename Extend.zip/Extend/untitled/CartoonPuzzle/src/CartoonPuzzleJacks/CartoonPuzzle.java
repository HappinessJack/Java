package CartoonPuzzleJacks;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.util.Random;

class JF extends JFrame {
    //declare two variable to store the number of 0's index ;
    private int g;
    private int h;

    JPanel jP;
    private JButton upButton;
    private JButton downButton;
    private JButton leftButton;
    private JButton rightButton;
    private JButton helpButton;
    private JButton resetButton;
    private int[][] iA = new int[][]{{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 0}};

    public JF(
    ) {
        this.iF();
        this.addButton();
        this.randomArrayElement();
        this.WCtD();
        this.getElement();
        this.addPic();
        this.setVisible(true);
        this.addButtonActionListener();

    }

    //initialize windows
    public void iF() {
        this.setDefaultCloseOperation(03);
        this.setSize(960, 565);
        this.setAlwaysOnTop(true);
        this.setLocationRelativeTo(null);
//cancel windows default layout ;
        this.setLayout(null);
        this.setTitle("CartoonPuzzle");
    }
//define a function to check right or no finish the puzzle  ;
    public boolean isFinish(){
       int[][] iA1 = new int[][] {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,0}} ;
        for (int i = 0; i < iA.length; i++) {
            for (int i1 = 0; i1 < iA[i].length; i1++) {
        if(iA[i][i1]!=iA1[i][i1]){
return false ;
        }
            }
        }
        iA = new int[][]{{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
        return true ;
    }
    //component drawing ;
    public void repaintPanel() {
        jP.removeAll();
        for (int i = 0; i < iA.length; i++) {
            for (int i1 = 0; i1 < iA[i].length; i1++) {
                ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\" + iA[i][i1] + ".png");
                JLabel imageLabel = new JLabel(iI);
                imageLabel.setBounds(90 * i1, 90 * i, 90, 90);
                jP.add(imageLabel);


            }
            jP.repaint();
        }
    }

    public void WCtD() {
        //title image
        JLabel jL = new JLabel(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\title.png"));
        jL.setBounds(354, 27, 232, 57);
        this.add(jL);
        //declare a two-dimensional array to store image number date ;and user change image location ;
        // int[][] iA = new int[][] {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}} ;
        jP = new JPanel();
        jP.setBounds(150, 114, 360, 360);
        jP.setLayout(null);
        //through use the two-dimensional array,add image ,and change the location of image  ;
        for (int i0 = 0; i0 < iA.length; i0++) {
            for (int i1 = 0; i1 < iA[i0].length; i1++) {
                ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\" + iA[i0][i1] + ".png");
                //declare a component to add Image ;
                JLabel imageLabel = new JLabel(iI);
                imageLabel.setBounds(90 * i1, 90 * i0, 90, 90);
                this.add(imageLabel);
                jP.add(imageLabel);
            }
        }
        this.add(jP);
    }

    //Add up,down,left,right,help and reset Button ;
    public void addButton() {
        upButton = new JButton(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\shang.png"));
        upButton.setBounds(732, 265, 57, 57);
        this.add(upButton);
        downButton = new JButton(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\xia.png"));
        downButton.setBounds(732, 347, 57, 57);
        this.add(downButton);
        rightButton = new JButton(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\you.png"));
        rightButton.setBounds(813, 347, 57, 57);
        this.add(rightButton);
        leftButton = new JButton(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\zuo.png"));
        leftButton.setBounds(650, 347, 57, 57);
        this.add(leftButton);
        helpButton = new JButton(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\qiuzhu.png"));
        helpButton.setBounds(626, 444, 108, 45);
        this.add(helpButton);
        resetButton = new JButton(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\chongzhi.png"));
        resetButton.setBounds(786, 444, 108, 45);
        this.add(resetButton);

    }

    //add a Reference Map and a backGround
    public void addPic() {
        JLabel referenceMap = new JLabel(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\canzhaotu.png"));
        referenceMap.setBounds(574, 114, 122, 121);
        this.add(referenceMap);
        JLabel background = new JLabel(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\background.png"));
        background.setBounds(0, 0, 960, 530);
        this.add(background);
    }

    public void randomArrayElement() {
        for (int ai = 0; ai < iA.length; ai++) {
            for (int ai1 = 0; ai1 < iA[ai].length; ai1++) {
                Random r = new Random();
                Random r2 = new Random();
                int i1 = r.nextInt(iA.length);
                int i2 = r2.nextInt(iA[ai].length);
                int medium = iA[ai][ai1];
                iA[ai][ai1] = iA[i1][i2];
                iA[i1][i2] = medium;


            }
        }
    }

    //define a function to disable button ;
    public void setButtonUnuse() {
        rightButton.setEnabled(false);
        leftButton.setEnabled(false);
        upButton.setEnabled(false);
        downButton.setEnabled(false);
    }

    public void setButtonUse() {
        rightButton.setEnabled(true);
        leftButton.setEnabled(true);
        upButton.setEnabled(true);
        downButton.setEnabled(true);
    }

    //define a function to get index of number 0 ;
    public void getElement() {
        r:
        for (int i = 0; i < iA.length; i++) {
            for (int i1 = 0; i1 < iA.length; i1++) {
                if (iA[i][i1] == 0) {
                    g = i;
                    h = i1;

                    System.out.println("iA[" + this.g + "]" + "[" + this.h + "]");
                    break r;
                }
            }
        }
    }

    //define a function to achieve add action listener for up,down.left,right,help and reset button
    public void addButtonActionListener() {
        upButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (g == 3) {
                    return;
                }
                iA[g][h] = iA[g + 1][h];
                iA[g + 1][h] = 0;
                g = g + 1;
                isFinish() ;
                repaintPanel();

            }
        });
        downButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (g == 0) {
                    return;
                }
                iA[g][h] = iA[g - 1][h];
                iA[g - 1][h] = 0;
                g -= 1;
                isFinish() ;
                repaintPanel();

            }

        });
        leftButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (h == 3) {
                    return;
                }
                iA[g][h] = iA[g][h + 1];
                iA[g][h + 1] = 0;
                h += 1;
                isFinish() ;
                repaintPanel();

            }
        });
        rightButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (h == 0) {
                    return;
                }
                iA[g][h] = iA[g][h - 1];
                iA[g][h - 1] = 0;
                h -= 1;
                isFinish() ;
                repaintPanel();

            }
        });
        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iA = new int[][]{{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
                repaintPanel();
                setButtonUnuse();
            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iA = new int[][]{{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 0}};
                randomArrayElement();
                getElement() ;
                repaintPanel();
                setButtonUse();
            }
        });
    }

}
//define a function to achieve Generate random array element ;


public class CartoonPuzzle {
    public static void main(String[] args) {

        new JF();
    }

}
