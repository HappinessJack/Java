import javax.swing.*;

public class JLabelTest0 {
    public static void main(String [] args){
        JLabel textLabel = new JLabel(new ImageIcon("C:\\Users\\admin\\Downloads\\123\\images\\title.png")) ;
        textLabel.setBounds(0,0,200,100);
        JFrame frame = new JFrame() ;
        frame.setLayout(null);
       frame.setSize(1920,1080) ;
       frame.add(textLabel) ;
        frame.setVisible(true);
    }
}
