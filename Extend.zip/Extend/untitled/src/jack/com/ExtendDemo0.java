package jack.com;
import javax.swing.JFrame;
import javax.swing.JButton ;
import javax.swing.JLabel ;
import javax.swing.JTextField ;
import javax.swing.JPasswordField ;
import java.awt.event.ActionListener ;
import java.awt.event.ActionEvent ;
import javax.swing.JOptionPane ;
import javax.swing.* ;
class LoginOperation extends JFrame{
    public LoginOperation() {
    this.iJ() ;
    this.pJ() ;
        this.setVisible(true);
    }
//initialize JFrame ;
        public void iJ() {
            this.setTitle("UserLoginSystem");
            this.setBounds(100, 100, 400, 300);
            this.setDefaultCloseOperation(3);
            this.setLayout(null);
            this.setAlwaysOnTop(true);
            this.setLocationRelativeTo(null);
        }
        //paint Windows ;
        public void pJ() {
            //add two Label in the container ;
            JLabel label1 = new JLabel("用户名");
            JLabel label2 = new JLabel("密码");
            //set the label location ;
            label1.setBounds(50, 50, 50, 20);
            label2.setBounds(50, 100, 50, 20);
            this.add(label2);
            this.add(label1);
            //set two field
            JTextField usernameField = new JTextField();
            usernameField.setBounds(150, 50, 180, 20);
            JPasswordField passwordField = new JPasswordField();
            passwordField.setBounds(150, 100, 180, 20);
            this.add(usernameField);
            this.add(passwordField);
            // fix a button of login ;
            JButton button = new JButton("login");
            button.setBounds(50, 200, 280, 20);
            //Put the button in the container
            this.add(button);
        }


}
public class ExtendDemo0 {
    public static void main(String [] args) {
  new LoginOperation() ;
    }
}
