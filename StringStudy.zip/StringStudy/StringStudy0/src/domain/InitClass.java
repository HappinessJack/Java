package domain;

import String.study.ScannerString;

import java.util.Scanner;

public class InitClass {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in) ;
        System.out.println("please input number");
        ScannerString s = new ScannerString() ;
        s.setInputInt(sc);
        s.setInputString(sc);
        s.setInputString1(sc);
       s.printInfo();
    }
}
