package String.study;

import java.util.Scanner;

//use String.split split String ;
public class Student {
    private String name ;
    private String age ;

    public Student(String name,String age ) {
        this.name = name;
        this.age = age ;
    }
    public Student(){

    }

    public String getAge() {
        return this.age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getName() {
        return this.name;
    }
    public static void  main(String[] args){
        Scanner sc = new Scanner(System.in) ;
       String[] stringArray = sc.nextLine().split(",");
       Student s0 = new Student(stringArray[0],stringArray[1]) ;
        System.out.println(stringArray) ;
        System.out.println(s0.getAge()+"\n"+s0.getName());
        
    }
}
