package String.study;

import java.util.Scanner;

public class OutputAllCharacter {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in) ;
        char[] charArray =sc.nextLine().toCharArray() ;
        for(int i = 0;i < charArray.length;i++){
            System.out.println(charArray[i]);
        }
    }
}
