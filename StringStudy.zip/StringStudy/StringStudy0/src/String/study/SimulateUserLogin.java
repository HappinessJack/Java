package String.study;

import java.util.Scanner;

public class SimulateUserLogin {
    private String username;
    private String password;

    public SimulateUserLogin() {

    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    private String getPassword() {
        return this.password;
    }

    private String getUsername() {
        return this.username;
    }

    public int compareUsernameAndPassword(String inputUsername, String inputPassword,int i) {
        if (inputPassword.equals(this.password) && inputUsername.equals(this.username)) {
                System.out.println("login success");
                return 3 ;
            } else {
                System.out.println("login failed you have" + (2 - i) + "chance");
        return i ;
        }

        }


    public static void main(String[] args) {
        SimulateUserLogin simulateUser = new SimulateUserLogin();
        simulateUser.setPassword("admin666");
        simulateUser.setUsername("jack");
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
          i =  simulateUser.compareUsernameAndPassword(sc.next(),sc.next(),i);
        }
    }
}