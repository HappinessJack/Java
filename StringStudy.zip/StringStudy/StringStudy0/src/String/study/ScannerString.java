package String.study;

import java.util.Scanner;

public class ScannerString {
    private String inputString;
    private String inputString1;
private int inputInt ;
    public ScannerString() {

    }

    public void setInputString(Scanner sc) {
        this.inputString = sc.next();

    }

    public int getInputInt() {
        return this.inputInt;
    }

    public void setInputInt(Scanner sc){
        this.inputInt = sc.nextInt() ;
    }

    public void setInputString1(Scanner sc) {
        this.inputString1 = sc.nextLine();
    }

    public String getInputString() {
        return this.inputString;
    }

    public String getInputString1() {
        return this.inputString1;
    }
public void printInfo(){
        System.out.println(inputString + "\n" + inputString1 + "\n" + inputInt) ;
}
}

