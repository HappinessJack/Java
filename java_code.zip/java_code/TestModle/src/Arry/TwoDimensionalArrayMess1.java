package Arry;

import java.util.Random;

public class TwoDimensionalArrayMess1 {
    public static void main(String[] args){
        int[][] iA = new int[][] {{0,1,2,3},{4,5,6,7},{8,9,10,11}} ;
        Random r = new Random() ;
        for(int i = 0 ; i < iA.length;i++) {
            for (int j = 0; j < iA[i].length; j++) {
                int i1 = r.nextInt(iA.length);
                int i2 = r.nextInt(iA[i].length);
                int medium = iA[i][j];
                iA[i][j] = iA[i1][i2];
                iA[i1][i2] = medium;
            }
        }
        for(int i = 0 ; i < iA.length;i++) {
            for (int j = 0; j < iA[i].length; j++) {
                System.out.print(iA[i][j]);
            }}
    }
}
