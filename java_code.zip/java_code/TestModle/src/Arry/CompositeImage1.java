package Arry;
import javax.swing.*;

public class CompositeImage1 {
    public static void main(String [] args) {
        // add a JFrame to show a windows ;
        JFrame jF = new JFrame("ImageShow") ;
        //set the windows can be visited ;
        jF.setVisible(true);
        //set the size
        jF.setSize(400,400);
        //set the close operation ;
        jF.setDefaultCloseOperation(03);
        //set always in top no matter what  doing you ;
        jF.setAlwaysOnTop(true);
        //set the relative location in computer ;
        jF.setLocationRelativeTo(null);
        //cancel the default layout of windows ;
        jF.setLayout(null);
        //define a two-dimensional array

        int[] array = new int[] {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} ;
        //define a cycle to achieve add the number of image
/*
        for (int i = 0 ;i<16 ;i++){
            ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\1\\"+(i + 1) + ".png")
;
            JLabel jL = new JLabel(iI) ;
            jL.setBounds() ;

        }*/
    }
}
