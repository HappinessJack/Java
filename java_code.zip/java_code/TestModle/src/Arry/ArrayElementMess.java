package Arry;

import java.util.Random;

public class ArrayElementMess {
    public static void main(String [] args){
        //declare a two-dimensional array ;
        int[][] as = new int[][] {{1,2,3},{4,5,6},{7,8,9}} ;
        //declare a Random object
        Random r = new Random() ;
        //output the element of the array
        //as[i]
        for (int i = 0 ;i<as.length ;i++){
            //as[i][s]
            for (int s = 0 ;s<as[i].length ;s ++){
                //get a length of the two-dimensional ;
                int x = r.nextInt(as.length) ;
                //get a length of the one-dimensional ;
                int y = r.nextInt(as[i].length) ;
                //element exchange ;
                int medium = as[i][s] ;
         as[i][s] = as[x][y] ;
         as[x][y] = medium ;
            }
        }
        //out put the element of each array
        for (int i = 0 ;i<as.length ;i++){
            //as[i][s]
            for (int s = 0 ;s<as[i].length ;s ++){
        System.out.print(as[i][s] + " ")   ;
            }
            System.out.println() ;
        }
    }
}
