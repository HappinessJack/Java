package Arry;
import javax.swing.JFrame ;
import javax.swing.ImageIcon ;
import javax.swing.JLabel ;
public class CompositeImage {
    public static void main(String [] args){
        JFrame jF = new JFrame("ImageShow") ;
       jF.setSize(380,400);
       jF.setDefaultCloseOperation(3) ;
       jF.setLocationRelativeTo(null) ;
       //let the windows always can not be lost ;
        jF.setAlwaysOnTop(true) ;
        jF.setLayout(null);
        //load image
        int j = 0 ;
        int k = 0 ;
        int l = 0 ;
for (int i = 0 ; i <= 15 ;i++){
    //i.png,x:i*90 ;
    ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\1\\" + (1+i) + ".png") ;
    JLabel jL = new JLabel(iI) ;

    if(i<=3){
    jL.setBounds(i*90,0,90,90);}
    jF.add(jL) ;
    if(3<i&&i<8){

        jL.setBounds(j*90,90,90,90) ;
        jF.add(jL) ;
        j++ ;
    }

if(i>=8&&i<=11){

        //k*90
        jL.setBounds(k*90,180,90,90);
        jF.add(jL) ;
        k ++ ;


}
if(i>=12&&i<=15){
    //l*90

        jL.setBounds(l*90,270,90,90);
        jF.add(jL) ;
   l++;
}
}



        jF.setVisible(true);
    }


}
