package Arry;

import javax.swing.*;

public class CompositeImagePro {
    public static void main(String [] args){
        JFrame jF = new JFrame("ImageShow") ;
        jF.setSize(380,400);
        jF.setDefaultCloseOperation(3) ;
        jF.setLocationRelativeTo(null) ;
        //let the windows always can not be lost ;
        jF.setAlwaysOnTop(true) ;
        jF.setLayout(null);
int[][] datas = new int[][]{
        {1,2,3,4},
        {5,6,7,8},
        {9,10,11,12},
        {13,14,15,16}
} ;
        for (int i = 0 ; i < datas.length; i++){
            for (int j = 0 ;j < datas[i].length;j++){
                ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\1\\" + (datas[i][j]) + ".png") ;
                JLabel jL = new JLabel(iI) ;
                jL.setBounds(j*90,i*90,90,90);
                jF.add(jL) ;
            }
        }
jF.setVisible(true) ;
    }
}
