package Arry;

import javax.swing.*;

public class Test {
    public static void main(String [] args){
        JFrame jF = new JFrame("ImageShow") ;
        jF.setSize(380,400);
        jF.setDefaultCloseOperation(3) ;
        jF.setLocationRelativeTo(null) ;
        //let the windows always can not be lost ;
        jF.setAlwaysOnTop(true) ;
        jF.setLayout(null);
        int i = 0 ;
        ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\1\\" + (1+i) + ".png") ;
        JLabel jL = new JLabel(iI) ;
        jL.setBounds(0,0,90,90);
        jF.add(jL) ;
        jF.setVisible(true);
    }
}
