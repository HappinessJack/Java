package Arry;

import javax.swing.*;
import java.util.Random;

public class CompositeImageMess {
    public static void main(String [] args){
        // add a JFrame to show a windows ;
        JFrame jF = new JFrame("ImageShow") ;

        //set the size
        jF.setSize(380,400);
        //set the close operation ;
        jF.setDefaultCloseOperation(03);
        //set always in top no matter what  doing you ;
        jF.setAlwaysOnTop(true);
        //set the relative location in computer ;
        jF.setLocationRelativeTo(null);
        //cancel the default layout of windows ;
        jF.setLayout(null);
        //define a two-dimensional array
        /*use the two-dimensional and achieve the add some image ,and keep them tidy in some time*/
        //because the fist Image's Location begin in (0,0,0,0),so make the number began in 0 ;
        int[][] aD= new int[][] {{0,1,2,3},{4,5,6,7},{8,9,10,11},{12,13,14,15}};
        //add a Random Machine ;
        Random r = new Random(15) ;
        //define a cycle to add image ;
        for (int i = 0 ;i< aD.length ;i++){
            for (int i1 = 0 ;i1<aD[i].length; i1 ++ ){
                int i2 = r.nextInt(4) ;
                int medium = aD[i][i1] ;
                aD[i][i1] = i2 ;

                 ImageIcon iI = new ImageIcon("C:\\Users\\admin\\Downloads\\1\\" + (1 + aD[i][i1]) + ".png") ;
                JLabel jL = new JLabel(iI) ;
                jL.setBounds(90*i1,90*i,90,90) ;
                jF.add(jL) ;
            }
        }
        //set the windows can be visited ;
        jF.setVisible(true);
    }
}
