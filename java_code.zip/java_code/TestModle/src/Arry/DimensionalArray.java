package Arry;

public class DimensionalArray {
    public static void main(String[] args){
        //declare a dimensional Array
        int[][] as1 = new int[][]{{888,88,8,7},{999,99,9},{000,00,0}} ;
        System.out.println(as1.length);
        //output the element of dimensional
       // as1[i]
        for (int i=0 ;i<as1.length;i++){
            //as1[i][i1]
            //adda a ln when a one-dimensional beginning
            System.out.print("Array :" + i ) ;

            for(int i1 = 0 ;i1<as1[i].length;i1++){
                System.out.print(as1[i][i1] + "," + "\t");
            }

        }
 System.out.println("-----------------");
        //case2
        /*for (int i = 0 ;i<as1.length;i++){
            System.out.println(as1[i][i]);
        }*///failed.
    }

}
