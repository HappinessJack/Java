package Arry;

public class TwoDimensionalArray {
    public static void main(String [] args){
        int[][] as = new int[][] {{123,12,1},{12,11,14},{999,9},{8888,8}} ;
        //use form type to visit the two-dimensional array ;
        System.out.println(as[1][2]);
        //output the two-dimensional Array address ;
        System.out.println(as);//[[I@5fd0d5ae
        //output the one-dimensional array
        System.out.println(as[0]);//[I@2d98a335
        System.out.println(as[1]);//[I@16b98e56
        //change the value of the element
        as[0][2] = 999999999;
        System.out.println(as[0][2]);
    }
}
