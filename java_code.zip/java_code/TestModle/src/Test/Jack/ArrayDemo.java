package Test.Jack;

public class ArrayDemo {
    public static void main(String [] args){
       // declare a array and give him initial value ;
        //a way
       int[] scoreArray = new int[]{999,99,9,666,66,6} ;
       System.out.println(scoreArray);//[I@5fd0d5ae
       //other way ;
       int[] scoreArray2 = {999,99,9,666,66,6} ;
       System.out.println(scoreArray2);
       //output the element in Array
        System.out.println(scoreArray[00]);//output 999 ;
        System.out.println(scoreArray[01]);//output 99 ;
        System.out.println(scoreArray[02]);;//output 9 ;
        //System.out.println(scoreArray[06]);;//output a error ;
//change the element in Array ;
        System.out.println("-----------------------------------------------------------------------------");
scoreArray[0] = 0 ;
        System.out.println(scoreArray[0]);

    }
}
