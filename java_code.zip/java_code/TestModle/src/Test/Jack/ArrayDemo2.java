package Test.Jack;

public class ArrayDemo2 {
    public static void main(String [] args){
        int[] iA = new int[]{999,99,9} ;
        System.out.println(iA[00]);
        System.out.println(iA[01]);
        System.out.println(iA[02]);
        //another way output the Array's element ;
        for(int i = 0  ;i <=2 ;i++){
            System.out.println(iA[i]);
            //output the Array's length ;

        }//the plus of the for ;
        for(int i = 0  ;i <iA.length ;i++){
            System.out.println(iA[i]);
    }}
}
