package Test.Jack;

public class RandomElement {
public static void main(String [] args){
    int[] intArray = new int[]{9999,999,99,9} ;
    for(int i = 0 ; i<intArray.length ;i++){
        System.out.println("unchanged" + intArray[i]);
    }
    //exchange the index0 and the index2 ;
    int medium = intArray[0] ;
    intArray[0] = intArray[2] ;
    intArray[2] = medium ;
    for(int i = 0 ; i<intArray.length ;i++){
        System.out.println("changed" + intArray[i]);
    }

}
}
