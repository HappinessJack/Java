package Test.Jack;

public class ArrayRandom2 {
    public static  void main(String [] args){
        int[] randomArray = new int[3] ;
        //output the address of Array ;
        System.out.println(randomArray);
        //output the array element ;
        System.out.println(randomArray[0]);
        System.out.println(randomArray[1]);
        System.out.println(randomArray[2]);
        System.out.println("------------------------------");
        //change the array's element ;
        randomArray[0] = 888 ;
        randomArray[1] = 88 ;
        randomArray[2] = 8 ;
        //output the array element ;
        System.out.println(randomArray[2]);
        System.out.println(randomArray[1]);
        System.out.println(randomArray[0]);
    }
}
