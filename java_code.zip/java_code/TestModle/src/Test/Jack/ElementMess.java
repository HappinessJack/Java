package Test.Jack;
import java.util.Random  ;
public class ElementMess {
    public static void main(String [] args){
        Random r = new Random() ;
        int[] intArray = new int[]{9999,999,99,9} ;
       // int indexRandom = r.nextInt(intArray.length) ;

//first Array element exchange ;
      /*  int medium = intArray[0];
        intArray[0] = intArray[indexRandom] ;
        intArray[indexRandom] = medium;
        //the second exchange
        indexRandom = r.nextInt(intArray.length) ;
        medium = intArray[1];
        intArray[1] = intArray[indexRandom] ;
        intArray[indexRandom] = medium;
        //output the array's element ;
        for (int i =0  ;i<intArray.length;i++){
            System.out.println(intArray[i]);*/
        //exchange every element with the random element ;
       for(int i=0 ;i<intArray.length;i++){
           int medium = intArray[i];
           int randomIndex = r.nextInt(intArray.length) ;
           intArray[i] = intArray[randomIndex] ;
           intArray[randomIndex] = medium ;
       }
        for (int i =0  ;i<intArray.length;i++){
            System.out.println(intArray[i]);}
        }
    }

