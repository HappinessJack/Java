package Test.Jack;

public class MaxValue {
    public static void main(String [] args){
        int[] intArray = new int[] {999999,888888,88,999,1000000000} ;
        int max = intArray[0]  ;
        for (int i = 0;i<intArray.length;i++){
            if (max<intArray[i]){
                max = intArray[i] ;

            }

        }
        System.out.println(max);
    }
}
