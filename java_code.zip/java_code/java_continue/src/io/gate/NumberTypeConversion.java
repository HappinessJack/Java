package io.gate;

public class NumberTypeConversion {
    public static void main(String [] args){
        //int conversion to String type
        int i1 = 1 ;
        // case: 1
        String s1 = i1 + "" ;
        System.out.println(s1);
    //case :2
        String s2 = String.valueOf(i1) ;
        System.out.println(s2);
        System.out.println("--------------------------------------------------------------");
        //String conversion to int ;
        //case: 1
        String s3 = "99999999" ;
        int i3 = Integer.valueOf(s3) ;
        System.out.println(i3);
        //case: 2
        Integer in1 = Integer.valueOf(s3) ;
        int i4 = in1.intValue() ;
        System.out.println(i4);
        // case :3
        int i5 = Integer.parseInt(s3) ;
        System.out.println(i5) ;
    }
}
