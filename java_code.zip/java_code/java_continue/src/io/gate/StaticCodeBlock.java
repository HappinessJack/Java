package io.gate;
//define a non-main class
class Person{
    public Person(){
        System.out.println("constructorImplement");
    }//the static code block priority over the constructor code block
    static{
        System.out.println("staticImplement") ;
    }
    {System.out.println("constructorBlockImplement") ;}
}
public class StaticCodeBlock {

    public static void main(String [] args){
        new Person() ;
        new Person() ;
    }
}
