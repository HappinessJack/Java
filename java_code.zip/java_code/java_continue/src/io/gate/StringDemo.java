package io.gate;

public class StringDemo {
    public static void main(String [] args){
        //declare a String object
        String str = new String() ;
        System.out.println(str) ;
        System.out.println(str.length()) ;
        System.out.println("------------------------------") ;
    String str2 = new String("io. gate") ;
    System.out.println(str2) ;
        System.out.println(str2.length()) ;
        System.out.println("------------------------------") ;
        //该类String表示字符串。Java 程序中的所有字符串文字，例如"abc"，都实现为此类的实例
    String str3 = "abc" ;
        System.out.println(str3) ;
        System.out.println(str3.length()) ;
    }
}
