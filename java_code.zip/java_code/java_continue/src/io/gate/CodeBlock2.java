package io.gate;

public class CodeBlock2 {
    public static void main(String [] args) {
        //    int x = 1000 ;Returns the error message that the variable already exists
        {
            int x = 10 ;
            System.out.println("x = " + x);
        }
        int x = 100 ;
        System.out.println("x = " + x);
}}

