package io.gate;
import javax.swing.* ;
import java.awt.event.ActionListener ;
import java.awt.event.ActionEvent ;
public class ActionListenertest {
    public static void main(String[] args) {
        //add a container of Frame
        JFrame jF = new JFrame("ActionListenerTest");

        jF.setLocationRelativeTo(null);
        jF.setSize(400, 300);
        jF.setDefaultCloseOperation(3);
        jF.setAlwaysOnTop(true);
        jF.setLayout(null);
        //fix a Button of component on the container
        JButton actionButton = new JButton("click Me");
        actionButton.setBounds(0, 0, 300, 300);
        jF.add(actionButton);

        actionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent f) {
                System.out.println("click out");

            }
        });
        jF.setVisible(true);
    }
}