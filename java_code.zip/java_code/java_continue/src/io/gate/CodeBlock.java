package io.gate;

public class CodeBlock {
    private int s = 10 ;
    public CodeBlock(){
        //constructor block and constructor code;
        System.out.println("Constructor");
    }//the constructor block priority over constructor
    {System.out.println("constructor Block");}
    public static void main(String [] args){
        int s = 100 ;
        CodeBlock test = new CodeBlock() ;
        new CodeBlock() ;
        new CodeBlock() ;
        System.out.println(s) ;
        System.out.println(test.s) ;

    }
}
