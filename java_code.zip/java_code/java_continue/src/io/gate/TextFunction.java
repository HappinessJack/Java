package io.gate;

import java.sql.Date;

public class TextFunction {
public static void main(String [] args){

    System.out.println(d) ;
}
}
