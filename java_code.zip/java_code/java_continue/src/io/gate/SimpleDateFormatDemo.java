package io.gate;
import java.text.ParseException;
import java.text.SimpleDateFormat ;
import java.util.Date ;

public class SimpleDateFormatDemo {
    public static void main(String [] args) throws ParseException {
// sDF = new SimpleDateFormat() ;
        /*SimpleDateFormat sDF2 = new SimpleDateFormat("yyyy:MM:dd") ;
System.out.println(sDF) ;
        System.out.println(sDF2) ;return some address
        */
        Date d1 = new Date() ;
        //set  Specify the format
        SimpleDateFormat sDF = new SimpleDateFormat("yyyy.MM.dd  kk:mm:ss;SSSS") ;
        //SimpleDateFormat sDF = new SimpleDateFormat() ;
        String s1 = sDF.format(d1) ;
        System.out.println(s1) ;
        System.out.println("---------------------------------------------");
        // from String to date of type
        String s2 = "2222.11.11  11:11:11;1111" ;
        SimpleDateFormat sDF2 = new SimpleDateFormat("yyyy.MM.dd  kk:mm:ss;SSSS") ;
        Date d2 = sDF.parse(s2) ;
        System.out.println(d2) ;
    }



}
