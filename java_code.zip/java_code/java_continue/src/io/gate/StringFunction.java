package io.gate;

public class StringFunction {
    public static void main(String [] args) {
        //define three object of String class
        String str1 = "Itheima" ;
              String str2 = "itheima" ;
              String str3 = "itheima" ;
              System.out.println(str1.equals(str2)) ;
        System.out.println(str1.equals(str3)) ;
        System.out.println(str2.equals(str3)) ;
        System.out.println("------------------------------------") ;
        System.out.println(str1.equalsIgnoreCase(str2)) ;
        System.out.println(str1.equalsIgnoreCase(str3)) ;
        System.out.println(str2.equalsIgnoreCase(str3)) ;
        System.out.println("------------------------------------") ;
        String str4 = "                                                              ,,,. 1" ;
        System.out.println(str4) ;
        System.out.println(str4.trim()) ;
        //trim can only be used to remove leading and trailing spaces
    String str5 = "ju ju" ;
    System.out.println(str5.trim()) ;
    }
}
