package io.gate;
import java.util.Date ;

public class DateDemo {
    public static void main(String []args){
        //declare a chinaDate and give he a value ;
        Date chinaDate = new Date() ;
        System.out.println(chinaDate);//return System time ;
        Date chinaDate2 = new Date(1000*60*60) ;
        System.out.println(chinaDate2);//in standard base time later 1 hour ;just chinaDate+ 8 ;
    }
}
