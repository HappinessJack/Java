package io.gate;

public class Box {
    public static void main(String [] args){
        //Box
        Integer i1 = Integer.valueOf(111) ;
//autoBox
        Integer i2 = 111 ;
        //autoUnbox
        /*
        * i2 = i2 + 11
        * i2 = i2.valueInt() + 11 //autoUnbox
        * i2 = 122    //i2 = Integer.valueOf(122)
        */
        i2 += 11 ;
        System.out.println(i2);



    }
}
