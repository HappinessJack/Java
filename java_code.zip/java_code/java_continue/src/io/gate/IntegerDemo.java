package io.gate;

import java.net.SocketOption;

public class IntegerDemo {
    public static void main(String [] args){
        //Integer i1 = new Integer(100) ;it have been deprecated ;
       // Integer i1 = new Integer() ;will return a error
//these operations all can achieve return type of int  ;
       Integer i1 = Integer.valueOf(999) ;
        int i2 = Integer.valueOf("123") ;
        System.out.println(i1);
        System.out.println(i2);
    }
}
