package io.gate;



public class CodeBlock3 {
    static {
        System.out.println("-----------------Hellp---------------------");
    }    public static void main(String [] args) {


        System.out.println("ffffffffffffffffffffffffff");


        System.out.println();
    }


}
