package com.jack;
import javax.swing.JFrame ;
import javax.swing.JButton ;

public class GuiTest {
    public static void main(String [] args){
        JFrame jF = new JFrame("Hi") ;
        jF.setVisible(true) ;
        jF.setDefaultCloseOperation(3) ;
        jF.setSize(500,500) ;
    jF.setAlwaysOnTop(true) ;
        jF.setAutoRequestFocus(true) ;
        jF.setLocationByPlatform(false) ;
        jF.repaint(10000,400,400,600,800) ;
        JButton button = new JButton("Click") ;
       jF.add(button) ;
       button.setBounds(200,0,100,250) ;
        jF.setLayout(null) ;


    }
}
