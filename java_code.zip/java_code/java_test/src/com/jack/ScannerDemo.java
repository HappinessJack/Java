package com.jack;
import java.util.Scanner ;

public class ScannerDemo {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in) ;
        System.out.print("please input a number: ") ;
        System.out.println(sc.nextInt()) ;
        System.out.println("you input number is " + sc.nextInt()) ;
    }
}
