package com.jack;
import javax.swing.* ;
import java.util.Date ;
import java.text.SimpleDateFormat ;
public class ShowDateTime {
    //construct a container ;
    public static void main(String [] args){
        JFrame jF = new JFrame();
        jF.setTitle("phoneDateAndTimeDisplay");
        jF.setSize(400,300) ;
        jF.setLocationRelativeTo(null) ;
        jF.setAlwaysOnTop(true) ;
        jF.setLayout(null) ;
        jF.setDefaultCloseOperation(3) ;
        JLabel dateLabel = new JLabel("date") ;
        dateLabel.setBounds(50,50,100,20) ;
        jF.add(dateLabel) ;
        //declare a Date type object achieve display of date  ;
        Date dT = new Date() ;

        SimpleDateFormat sDF = new SimpleDateFormat("yyyy.MM.dd") ;
        String d = sDF.format(dT) ;
        JLabel showDateLabel =  new JLabel(d) ;
        showDateLabel.setBounds(50,80,200,20) ;
        jF.add(showDateLabel) ;
        SimpleDateFormat sDF2 = new SimpleDateFormat("HH:mm;ss") ;
      String t2 =  sDF2.format(dT) ;
        //show time
        JLabel timeLabel = new JLabel("Time") ;
        timeLabel.setBounds(50,150,100,20) ;
        jF.add(timeLabel) ;
        JLabel showTimeLabel = new JLabel(t2) ;
        showTimeLabel.setBounds(50,180,200,20) ;
        jF.add(showTimeLabel) ;
        jF.setVisible(true) ;
    }
}
