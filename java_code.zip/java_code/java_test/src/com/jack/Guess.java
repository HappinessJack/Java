package com.jack;
//import java.util package of Scanner class to achieve let programmer can input number
import java.util.Scanner ;
// import java.util package of Random to achieve produce a random number ;
import java.util.Random ;

public class Guess {
    public static void main(String[] args) {
        //declare a variable type of Random to receive the object address
        Random ranNum = new Random();
        //declare a variable to receive the random number ;
        int i = ranNum.nextInt(100) + 1;
        //declare a variable of Scanner type to receive the object address
        Scanner recipient = new Scanner(System.in);


        // instruct gamer input a number to play the game ;
        System.out.println("Please input a number");

        while (true) {
            //create a typewriter to receive the users input number ;
            int guessNum = recipient.nextInt();



            //write a judgment to judge the answer is it right or not ;
            if (guessNum < i) {
                System.out.println("You guessed small");
                System.out.print("Please input a number again :");
            } else if (guessNum > i) {
                System.out.println("you guessed big");
                System.out.print("Please input a number again :");
            } else {
                System.out.println("You are right");
                break;
            }
        }
    }
}



