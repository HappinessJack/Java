package com.jack;

import java.util.Scanner;

public class ScannerElement {

    public static void main(String [] args){
//through cycle achieve give the array value ;
        int[] a = new int[5] ;
        Scanner s = new Scanner(System.in) ;
        for(int i= 0 ;i<a.length ;i ++){
            System.out.println("please input NO:  " + (i+1) + "number") ;
            a[i] = s.nextInt();
        }
        ScannerElement.printlnFunction(a);



//define a function to print out the Array ;

}/*parameter type int[]
return type void ;
*/
public static void printlnFunction(int[] b){
    System.out.print("[");
        for (int i = 0 ; i < b.length;i++){

            if(i==b.length-1){
                System.out.print(b[i]);
            }
           else{ System.out.print(b[i] + ",") ;
        }

        } System.out.print("]");
}

}
