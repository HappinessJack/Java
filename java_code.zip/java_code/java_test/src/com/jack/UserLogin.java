package com.jack;
import javax.swing.JFrame;
import javax.swing.JButton ;
import javax.swing.JLabel ;
import javax.swing.JTextField ;
import javax.swing.JPasswordField ;
import java.awt.event.ActionListener ;
import java.awt.event.ActionEvent ;
import javax.swing.JOptionPane ;

public class UserLogin {
    public static void main(String [] args) {
        JFrame jF = new JFrame("loginframe");

jF.setBounds(100,100,400,300) ;
jF.setDefaultCloseOperation(3) ;
        jF.setLayout(null) ;
        jF.setAlwaysOnTop(true) ;

        //add two Label in the container ;
        JLabel label1 = new JLabel("用户名") ;
        JLabel label2 = new JLabel("密码") ;
        //set the label location ;
        label1.setBounds(50,50,50,20) ;
        label2.setBounds(50,100,50,20) ;
        jF.add(label2) ;
        jF.add(label1) ;
        //set two field
         JTextField usernameField = new JTextField() ;
         usernameField.setBounds(150,50,180,20) ;
        JPasswordField passwordField = new JPasswordField() ;
        passwordField.setBounds(150,100,180,20) ;
        jF.add(usernameField) ;
        jF.add(passwordField) ;
        // fix a button of login ;
        JButton button = new JButton("login") ;
        button.setBounds(50,200,280,20) ;
        //Put the button in the container
        jF.add(button) ;
        //password in database ;
        String users = "Jack" ;
        String password = "123456J" ;
      button.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e) {
              String password1 = passwordField.getText() ;
              String username = usernameField.getText() ;
              // determine whether the information entered by the users meets the requirements
              //determine the length of username whether meets the requirement
              if(username.length() >= 12 || username.length() <= 3 ){
                  //System.out.println("the username is to0 long or short,please re-enter") ;
                  //use dialog on container JFrame prompt user's error ;
                  JOptionPane.showMessageDialog(jF,"the username is too long or to short") ;
                  usernameField.setText("") ;
                 return ;
              }
              if(password1.equals(password) && username.equals(users)){
                //  System.out.println("loginSuccessful") ;
                  //fix a component of dialog on container Frame when your password and username right
              //the static function and static variable can use className to visit ;
                  JOptionPane.showMessageDialog(jF,"Success") ;
              passwordField.setText("") ;
              usernameField.setText("") ;
              }else{
                 // System.out.println("the username or password erro") ;
                  //fix a dialog
                  JOptionPane.showMessageDialog(jF,"The password or the username error") ;
              }
          }}) ;


        jF.setVisible(true);

    }
}
