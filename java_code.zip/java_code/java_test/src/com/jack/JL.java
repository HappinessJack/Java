package com.jack;

import javax.swing.*;

public class JL {
    public static void main(String[] args) {
        JFrame jF = new JFrame("achieve show imagine and text");
        jF.setVisible(true);
        jF.setBounds(100, 0, 800, 200);
        jF.setDefaultCloseOperation(3);
        JLabel label = new JLabel("study Carefully");
        jF.add(label);
        label.setBounds(10,100,100,100) ;
        //change the container default layout ;
        jF.setLayout(null) ;
        //declare a variable to receive the image location
        ImageIcon location = new ImageIcon("C:\\Users\\admin\\Downloads\\1.png") ;
        JLabel label2 = new JLabel(location) ;
    jF.add(label2) ;
    label2.setBounds(100,100,920,922) ;



    }
}
