package com.jack;
//import JFrame to achieve Graphical ;
import javax.swing.JFrame ;
//import JButton class to achieve fix button in windows
import javax.swing.JButton ;
/*
* constructor : JFrame
* 构造方法：
JFrame()：构造一个最初不可见的新窗体
成员方法：
void setVisible(boolean b)：显示或隐藏此窗体具体取决于参数b的值
void setSize(int width, int height)：调整此组件的大小，使其宽度为width，高度为height，单位是像素
* */
/*JButton：
按钮的实现
构造方法：
JButton(String text)：创建一个带文本的按钮
成员方法：
void setSize(int width, int height)：设置大小
void setLocation(int x, int y)：设置位置(x坐标，y坐标)*/
public class JFrameTest {
    public static void main(String [] args ){
        //declare a variable type of JFrame to receive object address ;
        JFrame pic = new JFrame();
        //show the graphical interface ;
        pic.setVisible(true) ;
        pic.setSize(400,400) ;
        //set a title for the windows ;
        pic.setTitle("LoliMake") ;
        pic.setLocationRelativeTo(null) ;
        //cancel windows default layout ;
        pic.setLayout(null) ;
        //let my windows in any interface top
        pic.setAlwaysOnTop(true) ;
        //fix a button in my windows
        JButton button1 = new JButton("poke me") ;
        button1.setSize(100,50) ;
        //button1.setLocation(0,0) ;find origin ;
        //set button location and size ;
        button1.setBounds(100,100,99,99);
        button1.setLocation(200,200) ;

        pic.add(button1) ;
        //change the setDefaultCloseOperation of value to achieve close the windows while close the programming ;
        pic.setDefaultCloseOperation(3) ;

    }

}
