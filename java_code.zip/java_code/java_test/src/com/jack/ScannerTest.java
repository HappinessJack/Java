package com.jack;
import java.util.Scanner ;
public class ScannerTest {
    public static void main(String [] args){
        Scanner inputNumber = new Scanner(System.in) ;
        System.out.println("please input your first number") ;
        int num1 = inputNumber.nextInt() ;
        System.out.println("your put first number: " + num1) ;
        System.out.println("please input your second number") ;
        int num2 = inputNumber.nextInt() ;

        System.out.println("your put second number" + num2) ;
        int sum = num1 + num2 ;
        System.out.println("sum of your input number :" + sum) ;


    }
}
