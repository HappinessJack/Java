package com.jack;
// import a package of Random class
import java.util.Random ;
//define a construction function


//define a number class
public class Number{
//define a function main
public static void main(String []args){
    //declare a  Random type of variable to receive the address of object
    Random randomNum = new Random() ;
    for(int i = 0 ;i <= 10; i++){
    int ran = randomNum.nextInt(12);
System.out.println(("The cycle" + (1 + i)) + ": " +ran) ;}
    }

}
