package com.jack;
//import GUI components

import javax.swing.JFrame ;
import javax.swing.JButton ;
import javax.swing.JTextField ;
import javax.swing.JLabel ;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random ;
import javax.swing.JOptionPane ;



public class GuessNumberFrame {
    public static void main(String [] args){
        //construct a container
        JFrame jF = new JFrame("guess number") ;

 jF.setBounds(100,100,400,300) ;
 jF.setDefaultCloseOperation(3) ;
 // fix a button of component in container ;
        JButton guessButton = new JButton("Guess") ;
        guessButton.setBounds(150,150,100,20);
        jF.add(guessButton) ;

        jF.setLayout(null) ;
        //fix a component of TextField in container ;
        JTextField tF = new JTextField() ;
        tF.setBounds(120,100,150,20) ;
        jF.add(tF) ;
        jF.setAlwaysOnTop(true) ;
        jF.setLocationRelativeTo(null) ;
        JLabel tip = new JLabel("the Machine had generated a random number") ;
        tip.setBounds(70,50,350,20) ;
jF.add(tip) ;
int theGuess = aNumber() ;
guessButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
String s10 = tF.getText().trim() ;
       //int i1 = Integer.parseInt(s10) ;if the s10 of String is empty will return some error ;
        if (s10.equals("")){
            JOptionPane.showMessageDialog(jF,"Please input number!") ;
            return ;
        }
        int i1 = Integer.parseInt(s10) ;
if (i1>theGuess){
    JOptionPane.showMessageDialog(jF,"you guess too big");
    tF.setText("");
}else if (i1<theGuess){
    JOptionPane.showMessageDialog(jF,"you guess too small") ;
    tF.setText("");
}
else{
    JOptionPane.showMessageDialog(jF,"you are right");
    tF.setText("");
}
    }
});

jF.setVisible(true);


    }
    //define a function to return a random ;
    public static int aNumber() {
        return new Random().nextInt(100) + 1 ;
    }}