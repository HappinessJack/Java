package com.jack;

public class Book {
    //achieve auto numbering ;
    private static long numbering ;
    private String name ;//book called
    private double price ;
    private static long count ;//total count
public Book(String name , double price){
    this.name = name ;
    this.price = price ;
    Book.numbering ++ ;
    Book.count ++ ;
    //setter and getter ignore

}
public String getInfo () {
    return "name :" + name + "numbering :" + numbering + "price :" + price ;
}
public long getCount(){
    return count ;
}
public static void main(String [] args){
    Book book1 = new Book("java",9999.9999) ;
    String info = book1.getInfo() ;
    System.out.println(info) ;
    Book book2 = new Book("jack'Lifelong\t",99999999.9999999999999) ;
    String info1 = book2.getInfo() ;
    System.out.println(info1) ;
    System.out.println(book1.getCount()) ;
    System.out.println(book2.getCount()) ;

}
}
