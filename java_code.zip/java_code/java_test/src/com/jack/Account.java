package com.jack;

public class Account {
    private String accountName ;
    private int balance ;
public Account (String accountName,int balance ){
    this.accountName = accountName ;
    this.balance = balance ;
}
public String getAccountInfo(){
    return "balance :" + balance + accountName ;
}
public static void main(String[] args){
    Account account = new Account("cow",9999999) ;
    String info = account.getAccountInfo() ;
    System.out.println(info) ;
}
}
