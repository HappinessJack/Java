package com.jack;
import javax.swing.* ;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener ;
public class ChatRoom {
    public static void main(String [] args){
        //create a container to bear this components
        JFrame jF = new JFrame() ;
        jF.setTitle("chartRoom") ;
        jF.setAlwaysOnTop(true);
jF.setLocationRelativeTo(null);
        jF.setDefaultCloseOperation(3) ;
        jF.setLayout(null) ;
        jF.setBounds(100,100,400,300) ;
        //fix  button of components on contain
        JButton button1 = new JButton("sent") ;
        jF.add(button1) ;
        button1.setBounds(200,230,70,20) ;
        JButton button2 = new JButton("Empty") ;
        button2.setBounds(280,230,100,20) ;




        jF.add(button2) ;
        //fix a field of components in the container ;
        JTextField chatField = new JTextField() ;
        chatField.setBounds(10,230,180,20) ;
        jF.add(chatField) ;
        //fix a Area of components on container ;
        JTextArea chatArea = new JTextArea() ;
        chatArea.setBounds(10,10,360,200) ;
        jF.add(chatArea) ;
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = chatField.getText() ;
                chatField.setText("");
                message = message.trim() ;
                //  chatArea.setText(m) ;
// use new function to achieve do not cover original information ;
                chatArea.append(message + "\n");
            }
        }) ;
        button2.addActionListener(new ActionListener() {
                                      @Override
                                      public void actionPerformed(ActionEvent e) {
                       chatArea.setText("")      ;
                                      }
                                  } );
                jF.setVisible(true);

    }
}
