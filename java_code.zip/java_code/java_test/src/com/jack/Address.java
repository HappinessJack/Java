package com.jack;

 class Address {
    private String country ;
    private String province ;
    private String city ;
    private String neighbor ;
    private int postCode ;
    public void setCountry (String country){
        this.country = country ;
    }
    public String getCountry(){
        return country ;
    }
    public void setProvince(String province){
        this.province = province ;
    }
    public String getProvince(){
        return province ;
    }
    public void setCity(String city){
        this.city = city ;
    }
    public String getCity(){
        return city ;
    }
    public void setPostCode (int postCode){
        this.postCode = postCode ;
    }
    public int getPostcode(){
        return postCode ;
    }
public void getInfo(){
        System.out.println("country:" + country + "province" + province + "city" +city + "postCode" + postCode +"neighbor" + neighbor + "postCode" + postCode) ;
}
    public static void main(String [] args){
Address ad1 = new Address() ;
ad1.setCountry("China") ;
ad1.setProvince("ZheJiang") ;
ad1.setCity("LiShui") ;
ad1.setPostCode(110)  ;
        ad1.getInfo() ;

    }
}
