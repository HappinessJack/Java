package com.jack;

public class User {
    private String userName ;
    private int password ;
    private static long userSum ;
    public User(){this.userSum() ;}
    public User (String userName){
        this.userName = userName ;
        this.userSum() ;
    }
    public User(String userName,int password) {
        this.userName = userName;
        this.password = password;
        this.userSum() ;
    }
        public void setPassword(int password){
        this.password = password ;

        }public void userSum(){
        User.userSum ++ ;
    }
    public long getUserSum(){
        return this.userSum ;
    }
        public int getPassword(){
        return password ;
        }
        public String getInfo(){
        return "userName" + userName + "password" + password ;
        }
    public static void main(String [] args){
        {User user1 = new User() ;
            String userInfo = user1.getInfo() ;
        System.out.println(userInfo) ;
        long info = user1.getUserSum() ;

        System.out.println(info) ;}
        {
            User user2 = new User("jack");
          String userInfo =  user2.getInfo() ;
          System.out.println(userInfo) ;
          long info = user2.getUserSum() ;
          System.out.println(info) ;
        }
        {User user2 = new User("moon",123456);
            String userInfo =  user2.getInfo() ;
            System.out.println(userInfo) ;
            long info = user2.getUserSum() ;
            System.out.println(info) ;}
    }
}
