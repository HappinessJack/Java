package com.jack;

import javax.swing.* ;
import com.jack.DateChooser ;

import java.text.ParseException;
import java.util.Date  ;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;

public class AttendanceInformatiion {
    public static void main(String [] args){
        JFrame jF = new JFrame();
        jF.setTitle("AttendanceInquiry ");
        jF.setSize(400,300) ;
        jF.setLocationRelativeTo(null) ;
        jF.setAlwaysOnTop(true) ;
        jF.setLayout(null) ;
        jF.setDefaultCloseOperation(3) ;
        //fix a component of Button on the container ;
JButton inquiry = new JButton("inquiry")  ;
inquiry.setBounds(250,180,60,20) ;
jF.add(inquiry) ;
JTextField timeField = new JTextField() ;
timeField.setBounds(50,100,100,20) ;


        DateChooser dateChooser = DateChooser.getInstance("yyyy.MM.dd");
        dateChooser.register(timeField) ;
        DateChooser dateChooser2 = DateChooser.getInstance("yyyy.MM.dd");
        jF.add(timeField) ;
        JTextField timeField2 = new JTextField() ;
        timeField2.setBounds(250,100,100,20) ;
        dateChooser2.register(timeField2) ;
        jF.add(timeField2) ;
        JLabel attendanceDate = new JLabel("AttendanceDate") ;
        attendanceDate.setBounds(50,20,100,20) ;
        jF.add(attendanceDate) ;
        JLabel attendanceTime1 = new JLabel("StartingTime") ;
        attendanceTime1.setBounds(50,70,100,20) ;
        jF.add(attendanceTime1) ;
        JLabel attendanceTime2 = new JLabel("deadline") ;
        attendanceTime2.setBounds(250,70,100,20) ;
        jF.add(attendanceTime2) ;
        inquiry.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                SimpleDateFormat sDF = new SimpleDateFormat("yyyy.MM.dd") ;
                // get the start time and the end time String '
                String date1 = timeField.getText() ;
                String date2 = timeField2.getText() ;
                try {
                    Date d1 = sDF.parse(date1) ;
                    Date d2 = sDF.parse(date2) ;
                    JOptionPane.showMessageDialog(jF,d1 + "\n" + d2) ;
                } catch (ParseException ex) {
                    throw new RuntimeException(ex);
                }


            }
        }) ;
        jF.setVisible(true) ;
    }
}
