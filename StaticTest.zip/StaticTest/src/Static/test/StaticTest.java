package Static.test;

public class StaticTest {
    String name ;
    String age ;
    static String country ;
    StaticTest staticTest = new StaticTest();
    public static void show(){
        System.out.println(name + age + country);
    }
}
