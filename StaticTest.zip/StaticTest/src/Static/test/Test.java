package Static.test;

public class Test {
    public static void main(String[] args){
        StaticTest test = new StaticTest() ;
        test.name = "jack" ;
        test.age = "14" ;
        test.country = "china" ;
        test.show();
        StaticTest test1 = new StaticTest() ;
        StaticTest.country = "usa" ;
        test1.show();
        test.show();//static key word in public store ;
        test.staticTest = test ;
    }

}
