package domain;
//goal:make a student manage System ;
public class Student {
    private String studentId ;
    private String name ;
    private int age ;
    private String birthday ;
   //define a construct of four parameters
   public Student(String studentId,String name,int age ,String birthday){
       this.studentId = studentId ;
       this.name = name ;
       this.age = age ;
       this.birthday = birthday ;
   }
    public Student(){}

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getStudentId() {
        return this.studentId;
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public String getBirthday() {
        return this.birthday;
    }
}
