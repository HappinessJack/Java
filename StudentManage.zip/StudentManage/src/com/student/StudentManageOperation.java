package com.student;

import domain.Student;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentManageOperation {
    public static void main(String[] args) {
//build a main menu ;
        ArrayList<Student> studentList = new ArrayList<Student>();
        Scanner sc = new Scanner(System.in);
        //use the loop to achieve make application more use


        System.out.println("--------welcome to student manage system--------");
        loop0:
        while (true) {
            System.out.println("1 add student");
            System.out.println("2 delete student");
            System.out.println("3 update student");
            System.out.println("4 view student");
            System.out.println("5 exit");
            System.out.println("please input your choice:");
            String s1 = sc.next();
            switch (s1) {
                case "1":
                    //add Student
                    addStudent(studentList);
                    break;
                case "2":
                    //delete student ;
                    deleteStudent(studentList);
                    break;
                case "3":
                    //update student ;
                    updateStudentInfo(studentList);
                    break;
                case "4":
                    viewStudent(studentList);
                    //view student
                    break;
                //exit
                case "5":
                    System.out.println("goodbye");
                    break loop0;
                default:
                    System.out.println("input error,please input again");
            }
        }
    }//according to the StudentId to update info ;

    public static void updateStudentInfo(ArrayList<Student> studentList) {
        Scanner sc0 = new Scanner(System.in);
        System.out.println("please input the studentId what you want to change");
        String s0 = sc0.next();
        int i = getIndex(studentList, s0);
        if (i == -1) {
            System.out.println("not exist this student");
        } else {
            Student stu0 = studentList.get(i);
            System.out.println("please input the new name of student");
            String s1 = sc0.next() ;

            System.out.println("please input the new age of student");
            int i1 = sc0.nextInt() ;

            System.out.println("please input the new birthday of student");
            String s2 = sc0.next() ;
            Student stu = new Student(s0,s1,i1,s2) ;
            studentList.set(i,stu) ;
            System.out.println("update success");
        }
    }

    public static void deleteStudent(ArrayList<Student> studentList) {
        Scanner sc = new Scanner(System.in);
        System.out.println("please input studentId what you want delete");
        String s = sc.next();
        int i = getIndex(studentList, s);
        if (i != -1) {
            studentList.remove(i);
            System.out.println("delete success");
        } else {
            System.out.println("no exist this student");
        }
    }

    public static void viewStudent(ArrayList<Student> studentList) {
//if no student print a tips on command
        if (studentList.size() == 0) {
            System.out.println("not exist student info");
            return;
        } else {
            System.out.println("ID\tname\tage\tbirthday");
            for (int i = 0; i < studentList.size(); i++) {
                Student stu = studentList.get(i);
                System.out.println(stu.getStudentId() + "\t" + stu.getName() + "\t" + stu.getAge() + "\t" + stu.getBirthday());
            }
        }
    }

    //get special studentId Index;
// get whether the student have been store,judgements based:studentId ;
    public static int getIndex(ArrayList<Student> studentList, String studentId) {
        //if not exist return a value ;
        //check all element's studentId in Arraylist
        for (int i = 0; i < studentList.size(); i++) {
            if (studentId.equals(studentList.get(i).getStudentId())) {
                return i;
            }
        }
        return -1;
    }

    public static void addStudent(ArrayList<Student> studentList) {
        Scanner sc = new Scanner(System.in);
        System.out.println("please input studentId which your want to add:");
        String studentId = sc.next();
        if (getIndex(studentList, studentId) != -1) {
            System.out.println("the student have existed,please input again");
            addStudent(studentList);
            return;
        }
        System.out.println("please input student name which your want to add:");
        String name = sc.next();
        System.out.println("please input student age which your want to add:");
        int age = sc.nextInt();
        System.out.println("please input student birthday which your want to add:");
        String birthday = sc.next();
        Student stu = new Student(studentId, name, age, birthday);
        if (studentList.add(stu)) {
            System.out.println("add success");
        }
    }
}
