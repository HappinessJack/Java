package com;
//goal:swap int[] to StringBuilder and output like [s,s,ss,,s,s,s,s,,s] formal
public class StringBuilderAppendString {
    public static void main(String[] args){
        int[] iA0 = new int[] {1,2,3,4} ;
        System.out.println( appendNumber(iA0));
    }
    public static String appendNumber(int[] iA) {
        StringBuilder sb0 = new StringBuilder("[") ;
for(int i = 0;i<iA.length;i++){
    if(i<iA.length-1){
    sb0.append(iA[i]) ;

    }else{
        sb0.append(iA[i]).append("]") ;
    }
}
   return sb0.toString() ;
    }
}
