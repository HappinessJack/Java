package com;
//goal:swap StringBuilder to String,and swap String to StringBuilder
public class StringBuilderSwapString {
    //String to StringBuilder
    public static void main(String[] args){
    StringBuilder sb0 = new StringBuilder("I love java and math") ;
    //StringBuilder to String ;
    String s0 = sb0.toString() ;
    System.out.println(s0) ;
    System.out.println(sb0);
}}
