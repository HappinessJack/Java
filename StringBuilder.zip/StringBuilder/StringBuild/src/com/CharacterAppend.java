package com;

import java.util.Calendar;
//order:compare the StringBuilder with String append speed whose quicker ;
public class CharacterAppend {
    public static void main(String[] args){
        CharacterAppend.appendUseStringBuilderTime() ;
CharacterAppend.appendStringUseTime();
    }
    public static void appendStringUseTime(){
        String s0 = "" ;
        long begin = Calendar.getInstance().getTimeInMillis();
        for(int i = 0 ;i<50000;i++){
            s0 += i ;
        }
        long end = Calendar.getInstance().getTimeInMillis();
        System.out.println(end-begin);
}// print the StringBuilder append use time ;
public static void appendUseStringBuilderTime(){
        StringBuilder sb0 = new StringBuilder("") ;
    long begin = Calendar.getInstance().getTimeInMillis();
    for(int i = 0 ;i<50000;i++){
        sb0.append(i) ;
    }
    String s1 = sb0.toString();
    long end = Calendar.getInstance().getTimeInMillis();
    System.out.println(end-begin);
    }
}
