package com.jack.entry;
import com.jack.controller.StudentController ;
import java.util.Scanner;
import com.jack.controller.TeacherController ;
public class Entry {
    public static void main(String[] args){
        StudentController controller = new StudentController() ;
        TeacherController teacherController = new TeacherController() ;
Scanner sc = new Scanner(System.in) ;
System.out.println("----------welcome to edu info manage system");
while (true){
    //show a main menu ;
            System.out.println("please input your choice: 1.student manage  2.teacher manager  3.exit");
            String choice = sc.next();
            switch (choice) {
                case "1":
                    controller.studentManage() ;
                    //System.out.println("student");
                    break;
                case "2":
                    //System.out.println("teacher");
                    teacherController.chooseMenu();
                    break;
                case "3":
                    //System.out.println("exit");
                    System.out.println("goodbye");
                    System.exit(0);
                default:
                    System.out.println("input error,please input again");
                    break ;
            }
        }
    }
}
