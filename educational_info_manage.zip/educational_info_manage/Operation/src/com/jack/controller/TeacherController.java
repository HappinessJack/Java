package com.jack.controller;

import com.jack.service.TeacherService;
import domain.Teacher;

import java.util.Scanner;

public class TeacherController {
   private Scanner sc = new Scanner(System.in);
    private TeacherService tService = new TeacherService();

    public void chooseMenu() {
        //achieve function choose
        loop:while (true) {
            System.out.println("1.add teacher");
            System.out.println("2.delete teacher");
            System.out.println("3.view teacher");
            System.out.println("4.update teacher info");
            System.out.println("5.exit");
            System.out.println("please input your choice:");
            int chooseNumber = sc.nextInt();
            switch (chooseNumber) {
                case 1:
                    //System.out.println("add teacher");
                    addStudent();
                    break;
                case 2:
                    deleteTeacher() ;
                    //System.out.println("delete teacher");
                    break;
                case 3:
                    //System.out.println("view student");
                    viewTeacher() ;
                    break;
                case 4:
                    //System.out.println("update teacher info");
                    updateTeacherInfo() ;
                    break;
                case 5:
                    break loop;
                default:
                    System.out.println("your input number error");
                    break;

            }
        }
    }
    //update teacher info by id and print result in command
    public void updateTeacherInfo(){
        System.out.println("please input id which your want to update");
        String id =  sc.next() ;
        boolean result = tService.deleteTeacher(id) ;
        if(result){
            Teacher t0 = getTeacher(id);
            tService.addTeacher(t0) ;
            System.out.println("success");
        }else{
            System.out.println("no existed this teacher");
        }
    }
//use the id,name,age,birthday make a teacher object
    public Teacher getTeacher(String id) {
        System.out.println("please input name");
        String name = sc.next();
        System.out.println("please input age");
        String age = sc.next();
        System.out.println("please input birthday");
        String birthday =  sc.next();
        Teacher t0 = new Teacher(id,name,age,birthday) ;

        return t0;
    }

    //called Service delete teacher and print delete result in command ;
    public void deleteTeacher(){
System.out.println("please input id which your want to delete");
       String id =  sc.next() ;
       //give tService id and get a boolean ;
       boolean flag = tService.deleteTeacher(id) ;
       if(flag){
           System.out.println("delete success");
       }else{
           System.out.println("no existed this teacher");
       }
    }
    //print all teacher info in command ;
public void viewTeacher(){
       Teacher[] teachers = tService.viewTeacher() ;
       if(teachers==null){
           System.out.println("no existed any teachers");
           return ;
       }
       System.out.println("id"+"\t"+"name"+"\t"+"Age"+"\t"+"birthday");
       for(int i = 0;i<teachers.length;i++){
           if(teachers[i]!=null){
               System.out.println(teachers[i].getId()+"\t"+teachers[i].getName()+"\t"+teachers[i].getAge()+"\t"+teachers[i].getBirthday());
           }
       }
}
    public void addStudent() {
        System.out.println("please input id");
        String id = sc.next();
       int index = tService.isExisted(id) ;
       if(index!=-1){
           System.out.println("the teacher have existed");
           return ;
       }
      Teacher t0 = getTeacher(id) ;
      boolean flag = tService.addTeacher(t0) ;
      if(flag){
          System.out.println("add success");
      }else{
          System.out.println("add failed,the array is fulled");
      }
    }
}