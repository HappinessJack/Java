package com.jack.controller;

import com.jack.service.StudentService;
import domain.Student;

import java.util.Scanner;

public class StudentController {
    private static Scanner sc = new Scanner(System.in);
    private StudentService studentService = new StudentService();

    public StudentController() {
    }

    public void studentManage() {
        System.out.println("welcome to student manage system");
        loop0:
        while (true) {
            System.out.println("1 add student");
            System.out.println("2 delete student");
            System.out.println("3 update student");
            System.out.println("4 view all student");
            System.out.println("5 exit");
            System.out.println("please input your choice:");
            String choice = sc.next();
            switch (choice) {
                case "1":
                    addStudent();
                    // System.out.println("add");
                    break;
                case "2":
                    deleteStudent();
                    //System.out.println("delete");
                    break;
                case "3":
                    updateStudent();
                    //System.out.println("update");
                    break;
                case "4":
                    viewAllStudent();
                    //System.out.println("view");
                    break;
                case "5":
                    System.out.println("exit");
                    break loop0;
                default:
                    System.out.println("your input error,please input again");
                    break;
            }
        }
    }

    public void updateStudent() {
        System.out.println("please input studentId which you want to update");
        String id = sc.next();
        if (studentService.updateStudentInfo(id)) {
        inputInfo(id);
            System.out.println("success");
        } else {
            System.out.println("no existed this id");
        }
    }

    //delete student by student id ;
    public void deleteStudent() {
        System.out.println("please input student id which your want to delete");
        String id = sc.next();
        if (studentService.deleteStudent(id)) {
            System.out.println("delete success");
        } else {
            System.out.println("no exist this student");
        }

    }

    public void viewAllStudent() {

        Student[] allStudents = studentService.viewAllStudents();
        if (allStudents == null) {
            System.out.println("void student info");
            return;
        }
        System.out.println("ID\t" + "name\t" + "age\t" + "birth");
        for (int i = 0; i < allStudents.length; i++) {
            if (allStudents[i] != null) {
                System.out.println(allStudents[i].getId() + "\t" + allStudents[i].getName() + "\t" + allStudents[i].getAge() + "\t" + allStudents[i].getBirthday());
            }
        }
    }

    public void addStudent() {
        while (true) {
            System.out.println("please input the id");
            String id = sc.next();
            if (studentService.isExisted(id)) {
                if( inputInfo(id)) {
                    System.out.println("success");
                    return ;
                } else {
                    System.out.println("the student array had fulled");
                    return ;
                }
            } else {
                System.out.println("the student have been added");
            }
        }
    }
    //let user input info,and return a boolean ;
    public boolean inputInfo(String id){
        System.out.println("please input the name");
        String name = sc.next();
        System.out.println("please input the age");
        String age = sc.next();
        System.out.println("please input the birthday");
        String birthday = sc.next();
     boolean b =   studentService.addStudent(id, name, age, birthday);
        return b;
    }
}
