package com.jack.DAO;

import domain.Student;

public class DAO {
    private static Student[] students = new Student[5];

    public boolean addStudent(Student student) {
        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                students[i] = student;
                return true;
            }
        }
        return false;
    }//update student info by id;
    public void updateStudentInfo(String id){

    }
public boolean deleteStudent(String id){
        int deleteObjectIndex = this.getStudentIndex(id) ;
        if(isEmpty()||deleteObjectIndex==-1){
            return false ;
        }else{
            students[deleteObjectIndex]=null ;
            return true ;
        }
}//judge students whether empty ;
    public boolean isEmpty() {
        for (int i = 0; i < students.length; i++) {
            if (students[i] != null) {
                return false;
            }
        }
        return true;
    }
    //get the id point student index
    public int getStudentIndex(String id){
        for(int i = 0;i<students.length;i++) {
        if(students[i]!=null&&!isEmpty()&&id.equals(students[i].getId())){
            return i ;
        }
        }
        return -1 ;
    }
    public Student[] getAllStudents() {
        return students;
    }
}
