package com.jack.DAO;

import domain.Teacher;

public class TeacherDAO {
    private Teacher[] teachers = new Teacher[5];

    //add student
    public boolean addStudent(Teacher teacher) {
        boolean flag = false;
        //find null index to store the teacher object ;
        for (int i = 0; i < teachers.length; i++) {
            if (teachers[i] == null) {
                teachers[i] = teacher;
                flag = true;
                break  ;
            }
        }
        return flag;
    }
    //return teachers array ;
public Teacher[] viewTeacher(){
        return teachers ;
}
    //judge whether hava existed this student ;
    public int isExisted(String id) {
       int index = -1 ;
        for (int i = 0; i < teachers.length; i++) {
            if (teachers[i]!=null&&id.equals(teachers[i].getId())) {
                index = i ;
            }
        }
        return index;}
    //judge whether is empty ;
    public boolean isEmpty(){
        for(int i = 0;i<teachers.length;i++){
            if(teachers[i]!=null){
                return false ;
            }
            }
    return true ;}
    //delete teacher and return a boolean ;
    public boolean deleteTeacher(String id){
        //get index
        int index = isExisted(id) ;
        if(index!=-1){
            teachers[index]=null ;
            return true ;
        }else{
            return false ;
        }
    }
}

