package com.jack.service;

import com.jack.DAO.DAO;
import domain.Student;

public class StudentService {
    private DAO dAO = new DAO();

    public StudentService() {
    }
//receive student id
    public boolean updateStudentInfo(String id){
        boolean b =  deleteStudent(id) ;
        return b ;
    }
    public boolean addStudent(String id, String name, String age, String birthday) {
        Student student = new Student(id, name, age, birthday);
        return dAO.addStudent(student);
    }
public Student[] viewAllStudents(){
        if(dAO.isEmpty()){
            return null ;
        }else{
           return dAO.getAllStudents() ;
        }
}
//judge student whether exist ;
    public boolean isExisted(String id) {
        //assume is not exist ;
        boolean flag = true;
        Student[] students = dAO.getAllStudents();
        for (int i = 0; i < students.length; i++) {
            if (students[i] != null && id.equals(students[i].getId())) {
                flag = false;
            }
        }
        return flag;
    }
    public boolean deleteStudent(String id){
        //get a boolean value;
     return dAO.deleteStudent(id);
    }

}
