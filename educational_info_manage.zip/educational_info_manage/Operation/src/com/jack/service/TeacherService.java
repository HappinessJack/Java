package com.jack.service;
import com.jack.DAO.TeacherDAO;
import domain.Teacher;

public class TeacherService {
    private TeacherDAO dAO = new TeacherDAO() ;
    //add student service ;
    public boolean addTeacher(Teacher teacher){
       return  dAO.addStudent(teacher) ;
    }
    //return the dAO judge result ;
    public int isExisted(String id){
        return dAO.isExisted(id) ;
    }
    //get teachers in array ;
    public Teacher[] viewTeacher(){
        if(dAO.isEmpty()){
            return null ;
        }
        return dAO.viewTeacher() ;
    }
    //called DAO delete teacher by id and return a boolean ;
    public boolean deleteTeacher(String id) {
        return dAO.deleteTeacher(id);
    }

}
